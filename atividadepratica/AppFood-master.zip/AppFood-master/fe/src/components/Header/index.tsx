
//import logo from "../../assets/images/logo.svg"

import { Container, Content } from "./styles";

export function Header() {
    return (
        <Container>
            <Content>
            <div className="page-details">
            <img src="C:\Users\joao.eduardo\Desktop\ifpr.svg"/>
                
                <h2>IFPR - Cascavel</h2>
            </div>

        </Content>
        </Container>
    );
}